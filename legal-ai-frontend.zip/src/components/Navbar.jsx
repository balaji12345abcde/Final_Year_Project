import { Link } from "react-router-dom";
import { useContext } from "react";
import { AuthContext } from "../context/AuthContext";

const Navbar = () => {
  const { token, logout } = useContext(AuthContext);

  return (
    <div className="bg-blue-600 text-white p-4 flex justify-between">
      <h1 className="font-bold">Legal AI</h1>
      <div className="space-x-4">
        {token && <Link to="/dashboard">Dashboard</Link>}
        {token && <Link to="/analyze">Analyze</Link>}
        {token && <button onClick={logout}>Logout</button>}
      </div>
    </div>
  );
};

export default Navbar;