import { useState, useContext } from "react";
import API from "../api";
import { AuthContext } from "../context/AuthContext";
import { useNavigate } from "react-router-dom";

export default function Login() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const { login } = useContext(AuthContext);
  const navigate = useNavigate();

  const handleLogin = async () => {
    const res = await API.post("login/", { username, password });
    login(res.data.access);
    navigate("/dashboard");
  };

  return (
    <div className="flex justify-center mt-20">
      <div className="bg-white p-8 shadow rounded w-96">
        <h2 className="text-xl mb-4">Login</h2>
        <input className="w-full border p-2 mb-3" placeholder="Username"
          onChange={(e) => setUsername(e.target.value)} />
        <input type="password" className="w-full border p-2 mb-3"
          placeholder="Password"
          onChange={(e) => setPassword(e.target.value)} />
        <button className="bg-blue-600 text-white w-full py-2"
          onClick={handleLogin}>Login</button>
      </div>
    </div>
  );
}