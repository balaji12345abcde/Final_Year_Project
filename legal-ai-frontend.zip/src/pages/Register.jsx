import { useState } from "react";
import API from "../api";
import { useNavigate } from "react-router-dom";

export default function Register() {
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const navigate = useNavigate();

  const handleRegister = async () => {
    await API.post("users/register/", { username, email, password });
    navigate("/");
  };

  return (
    <div className="flex justify-center mt-20">
      <div className="bg-white p-8 shadow rounded w-96">
        <h2 className="text-xl mb-4">Register</h2>
        <input className="w-full border p-2 mb-3"
          placeholder="Username"
          onChange={(e) => setUsername(e.target.value)} />
        <input className="w-full border p-2 mb-3"
          placeholder="Email"
          onChange={(e) => setEmail(e.target.value)} />
        <input type="password" className="w-full border p-2 mb-3"
          placeholder="Password"
          onChange={(e) => setPassword(e.target.value)} />
        <button className="bg-green-600 text-white w-full py-2"
          onClick={handleRegister}>Register</button>
      </div>
    </div>
  );
}