
import {useState} from "react";
import API from "../api";

export default function Analyze(){

  const [documentId,setDocumentId] = useState("");
  const [query,setQuery] = useState("");
  const [result,setResult] = useState(null);

  const analyze = async ()=>{
    const res = await API.post("nlp/analyze/",{
      document_id:documentId,
      query:query
    });

    setResult(res.data);
  }

  return(
    <div className="p-10">

      <h2 className="text-xl mb-4">Analyze Document</h2>

      <input
      className="border p-2 mr-3"
      placeholder="Document ID"
      onChange={(e)=>setDocumentId(e.target.value)}
      />

      <input
      className="border p-2 mr-3"
      placeholder="Query"
      onChange={(e)=>setQuery(e.target.value)}
      />

      <button
      className="bg-green-600 text-white px-4 py-2"
      onClick={analyze}>
      Analyze
      </button>

      {result &&
        <div className="mt-6 bg-white p-6 shadow">
          <p><b>Act:</b> {result.act_name}</p>
          <p><b>Section:</b> {result.section_number}</p>
          <p><b>Confidence:</b> {result.confidence_score}</p>
          <p><b>Risk:</b> {result.risk_level}</p>
          <p><b>Summary:</b> {result.summary}</p>
          <p><b>Explanation:</b> {result.explanation}</p>
          <p><b>Chatbot:</b> {result.chatbot_response}</p>
        </div>
      }

    </div>
  );
}
