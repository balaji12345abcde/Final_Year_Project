
import {Link} from "react-router-dom";

export default function Dashboard(){

  return(
    <div className="p-10">
      <h2 className="text-2xl font-bold mb-4">
      Legal Document Dashboard
      </h2>

      <Link
      className="bg-blue-600 text-white px-6 py-3"
      to="/analyze">
      Analyze Legal Document
      </Link>
    </div>
  );
}
