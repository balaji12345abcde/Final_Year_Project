
import {Link} from "react-router-dom";
import {useContext} from "react";
import {AuthContext} from "../context/AuthContext";

export default function Navbar(){

  const {token,logout} = useContext(AuthContext);

  return(
    <div className="bg-blue-600 text-white p-4 flex justify-between">
      <h1 className="font-bold">Legal AI</h1>

      {token &&
        <div className="space-x-4">
          <Link to="/dashboard">Dashboard</Link>
          <Link to="/analyze">Analyze</Link>
          <button onClick={logout}>Logout</button>
        </div>
      }
    </div>
  );
}
